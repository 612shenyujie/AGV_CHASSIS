//#include "pack_handler_bsp.h"

//void pack_handler_store(pack_queue_t *pack_queue, uint16_t pack_from_who, uint8_t, pack_length, uint8_t pack_content[])
//{
//		
//	
//}
